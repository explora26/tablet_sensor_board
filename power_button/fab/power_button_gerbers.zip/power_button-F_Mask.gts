%TF.GenerationSoftware,KiCad,Pcbnew,10.0.6*%
%TF.CreationDate,2026-10-19T04:08:42+00:00*%
%TF.ProjectId,power_button,706f7765-725f-4627-9574-746f6e2e6b69,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.6) date 2026-10-19 04:08:42*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,1.500000*%
%ADD11C,1.800000*%
%ADD12R,1.800000X1.800000*%
%ADD13RoundRect,0.200000X0.275000X-0.200000X0.275000X0.200000X-0.275000X0.200000X-0.275000X-0.200000X0*%
%ADD14RoundRect,0.250000X-0.350000X-0.625000X0.350000X-0.625000X0.350000X0.625000X-0.350000X0.625000X0*%
%ADD15O,1.200000X1.750000*%
%ADD16C,3.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,SW1*%
X114000000Y-116400000D03*
D11*
X111500000Y-113300000D03*
X116500000Y-113300000D03*
X114000000Y-110800000D03*
D12*
X114000000Y-113300000D03*
%TD*%
D13*
%TO.C,R1*%
X121000000Y-112825000D03*
X121000000Y-111175000D03*
%TD*%
D14*
%TO.C,J1*%
X111000000Y-103000000D03*
D15*
X113000000Y-103000000D03*
X115000000Y-103000000D03*
X117000000Y-103000000D03*
%TD*%
D16*
%TO.C,H1*%
X104500000Y-113000000D03*
%TD*%
M02*
